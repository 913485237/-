from __future__ import annotations

import json
from pathlib import Path

from contract_ai.agents.report_agent import ReportAgent
from contract_ai.pipeline import ContractReviewPipeline


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "outputs"
SAMPLE_CONTRACT = BASE_DIR / "sample_contracts" / "procurement_contract.txt"


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    text = SAMPLE_CONTRACT.read_text(encoding="utf-8")
    pipeline = ContractReviewPipeline()
    result = pipeline.run(text)

    (OUTPUT_DIR / "pipeline_result.json").write_text(
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    reporter = ReportAgent()
    (OUTPUT_DIR / "sample_review_report.md").write_text(reporter.report_markdown(result), encoding="utf-8")
    (OUTPUT_DIR / "redline_contract.md").write_text(result.redline_text, encoding="utf-8")
    print(f"合规评分：{result.compliance_score}/100")
    print(result.summary)
    print(f"输出目录：{OUTPUT_DIR}")


if __name__ == "__main__":
    main()
