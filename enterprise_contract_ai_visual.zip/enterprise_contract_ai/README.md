# 企业级智能合同审查与合规分析系统 MVP

这是一个基于“多 Agent 协作 + Hybrid RAG + 对抗反思”的企业合同审查 MVP。代码默认不依赖外部 LLM API，使用可审计的规则和知识库模拟核心流程，便于快速演示、二次开发和接入真实模型。

## 推荐使用方式：可视化操作台

面向公司内部法务、采购、风控和业务审批人员，建议优先使用 Streamlit 可视化界面，而不是命令行。

可视化操作台提供：

1. 合同文本上传或粘贴。
2. 审查强度和企业立场配置入口。
3. 多 Agent 审查流程展示。
4. 合规评分、风险总数、高风险数量、合同画像等 KPI 卡片。
5. 风险等级分布图。
6. 可筛选的风险矩阵。
7. 条款树与风险映射。
8. 单条款风险详情查看。
9. Redline 红线批注式修订建议。
10. 命中的法规、企业规则和标准条款依据。
11. JSON、Markdown 报告和 Redline 文本导出。

启动方式：

```bash
cd enterprise_contract_ai
pip install -r requirements.txt
streamlit run app.py
```

也可以使用脚本：

```bash
./start_visual_app.sh
```

Windows 可双击或执行：

```bat
start_visual_app.bat
```

## 命令行演示

```bash
cd enterprise_contract_ai
pip install -r requirements.txt
python run_demo.py
```

命令行会在 `outputs/` 目录生成结构化结果、审查报告和 Redline 修订建议。

## 核心架构

1. `ContractParserAgent`：解析合同文本，识别合同类型、法律关系、当事方，并拆解为条款树。
2. `HybridRAGAgent`：从企业合规红线、标准条款库和法律规则库中检索相关规则。
3. `RiskReasoningAgent`：基于条款证据和检索规则生成结构化风险发现。
4. `AdversarialReflectionAgent`：对风险结论进行反事实质疑与置信度修正。
5. `ReportAgent`：生成风险报告、合规评分和 Redline 修订建议。

## 目录说明

```text
enterprise_contract_ai/
├── app.py                              # Streamlit 可视化操作台
├── run_demo.py                         # 命令行演示入口
├── generate_result_images.py           # 生成架构图、风险矩阵图、界面预览图
├── start_visual_app.sh                 # Linux/macOS 启动脚本
├── start_visual_app.bat                # Windows 启动脚本
├── requirements.txt
├── sample_contracts/
│   └── procurement_contract.txt        # 示例采购合同
├── contract_ai/
│   ├── pipeline.py                     # 多 Agent 编排器
│   ├── schemas.py                      # 数据结构
│   ├── agents/
│   │   ├── parser_agent.py
│   │   ├── rag_agent.py
│   │   ├── risk_reasoning_agent.py
│   │   ├── reflection_agent.py
│   │   └── report_agent.py
│   └── knowledge_base/
│       └── rules.json                  # 合规规则与标准条款
└── outputs/
    ├── sample_review_report.md
    ├── redline_contract.md
    ├── pipeline_result.json
    ├── architecture.png
    ├── risk_matrix.png
    └── visual_console_preview.png
```

## 生产化改造建议

- 文档解析层：将 `ContractParserAgent` 替换为 OCR + LayoutLM + Word/PDF 解析器，支持扫描件、表格、印章、附件和签署页。
- 检索增强层：将 `HybridRAGAgent` 接入向量数据库、法规知识图谱、企业制度库、标准条款库和历史审查案例库。
- 推理层：将 `RiskReasoningAgent` 接入企业私有 LLM 或云端大模型，并要求模型输出严格 JSON Schema。
- 反思层：在 `AdversarialReflectionAgent` 中加入多轮自检、冲突检测、漏判检测和人工反馈学习。
- 权限与审计：增加用户角色、合同密级、操作日志、审批记录、版本留痕和导出水印。
- 企业集成：对接 OA、CLM、采购系统、印章系统、电子签和风控中台。

## 当前 MVP 边界

当前版本主要用于展示技术架构和业务闭环，不构成正式法律意见。生产环境应由企业法务确认审查规则、标准条款、风险分级和输出模板。
