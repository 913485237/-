from __future__ import annotations

import re
from typing import Iterable, List


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[\t\u3000]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_by_numbered_clauses(text: str) -> List[tuple[str, str]]:
    """Split contract text into numbered clauses.

    Supports Chinese numerals like 一、二、 and Arabic formats such as 1. / 1、.
    Returns list of (title, body). If no headings are found, returns paragraphs.
    """
    text = normalize_text(text)
    pattern = re.compile(
        r"(?m)^(?P<title>(?:第[一二三四五六七八九十百]+条|[一二三四五六七八九十]+、|\d+[\.、])[^\n]*)\n?"
    )
    matches = list(pattern.finditer(text))
    if not matches:
        paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        return [(f"段落{i + 1}", p) for i, p in enumerate(paras)]

    chunks: List[tuple[str, str]] = []
    for idx, match in enumerate(matches):
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        title = match.group("title").strip()
        body = text[start:end].strip()
        if body:
            chunks.append((title, body))
        else:
            chunks.append((title, title))
    return chunks


def contains_any(text: str, keywords: Iterable[str]) -> bool:
    lowered = text.lower()
    return any(k.lower() in lowered for k in keywords)


def extract_cross_references(text: str) -> List[str]:
    return re.findall(r"第[一二三四五六七八九十百]+条|\d+\.\d+|\d+条", text)
