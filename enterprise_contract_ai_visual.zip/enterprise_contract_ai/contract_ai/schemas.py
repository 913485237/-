from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass
from enum import Enum
from typing import Any, Dict, List, Optional


class RiskLevel(str, Enum):
    HIGH = "高风险"
    MEDIUM = "中风险"
    LOW = "低风险"


@dataclass
class Clause:
    clause_id: str
    title: str
    text: str
    domain: str
    references: List[str] = field(default_factory=list)


@dataclass
class ContractProfile:
    contract_type: str
    legal_relation: str
    jurisdiction: str
    parties: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievedRule:
    rule_id: str
    title: str
    source: str
    domain: str
    severity: str
    rule_text: str
    recommendation_template: str
    score_weight: int


@dataclass
class RiskFinding:
    finding_id: str
    clause_id: str
    domain: str
    risk_level: RiskLevel
    title: str
    evidence: str
    reasoning: str
    legal_basis: List[RetrievedRule]
    suggestion: str
    confidence: float
    challenged: bool = False
    reflection_note: Optional[str] = None


@dataclass
class ReviewResult:
    profile: ContractProfile
    clauses: List[Clause]
    findings: List[RiskFinding]
    compliance_score: int
    redline_text: str
    summary: str

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary.

        dataclasses.asdict keeps Enum instances as Enum objects, which breaks json.dumps.
        This recursive converter keeps the output stable for Streamlit download buttons,
        API responses and saved audit logs.
        """
        return _to_jsonable(self)


def _to_jsonable(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {f.name: _to_jsonable(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, list):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    return value
