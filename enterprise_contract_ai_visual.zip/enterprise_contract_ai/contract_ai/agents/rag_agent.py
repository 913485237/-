from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List

from contract_ai.schemas import Clause, RetrievedRule


class HybridRAGAgent:
    """Hybrid RAG placeholder: keyword/vector-style retrieval + rule graph filtering.

    The `rules.json` file simulates a compliance knowledge base. In production this layer should
    connect to vector DB, legal knowledge graph, internal policy database and clause library.
    """

    def __init__(self, rules_path: str | Path | None = None):
        if rules_path is None:
            rules_path = Path(__file__).resolve().parents[1] / "knowledge_base" / "rules.json"
        self.rules_path = Path(rules_path)
        self.rules = [RetrievedRule(**item) for item in json.loads(self.rules_path.read_text(encoding="utf-8"))]

    def run(self, clauses: Iterable[Clause]) -> Dict[str, List[RetrievedRule]]:
        retrieved: Dict[str, List[RetrievedRule]] = {}
        for clause in clauses:
            candidates = [rule for rule in self.rules if rule.domain == clause.domain]
            candidates += self._keyword_retrieve(clause.text)
            # stable de-duplication
            deduped = {rule.rule_id: rule for rule in candidates}
            retrieved[clause.clause_id] = list(deduped.values())[:5]
        return retrieved

    def _keyword_retrieve(self, text: str) -> List[RetrievedRule]:
        hits = []
        for rule in self.rules:
            haystack = f"{rule.title} {rule.rule_text} {rule.recommendation_template}"
            overlap = sum(1 for token in self._tokens(text) if token in haystack)
            if overlap >= 2:
                hits.append(rule)
        return sorted(hits, key=lambda r: r.score_weight, reverse=True)

    @staticmethod
    def _tokens(text: str) -> List[str]:
        domain_terms = [
            "违约", "赔偿", "责任", "上限", "间接损失", "知识产权", "保密", "争议", "仲裁", "管辖",
            "付款", "验收", "合规", "制裁", "个人信息", "解除", "不可抗力", "发票", "交付",
        ]
        return [term for term in domain_terms if term in text]
