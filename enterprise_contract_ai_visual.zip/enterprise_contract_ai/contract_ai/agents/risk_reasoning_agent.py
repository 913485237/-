from __future__ import annotations

import re
from typing import Dict, List

from contract_ai.schemas import Clause, RetrievedRule, RiskFinding, RiskLevel


class RiskReasoningAgent:
    """Generate structured risk findings.

    The reasoning rules below mimic LLM chain-of-thought outputs in a safe, auditable format:
    evidence -> issue -> business/legal impact -> suggested replacement.
    """

    def run(self, clauses: List[Clause], retrieved_rules: Dict[str, List[RetrievedRule]]) -> List[RiskFinding]:
        findings: List[RiskFinding] = []
        for clause in clauses:
            rules = retrieved_rules.get(clause.clause_id, [])
            findings.extend(self._detect_clause_risks(clause, rules))
        return findings

    def _detect_clause_risks(self, clause: Clause, rules: List[RetrievedRule]) -> List[RiskFinding]:
        text = clause.text
        risks: List[RiskFinding] = []

        def matched_rules(domain: str) -> List[RetrievedRule]:
            domain_rules = [r for r in rules if r.domain == domain]
            return domain_rules or rules[:1]

        if clause.domain == "违约责任" and re.search(r"乙方.*承担.*全部.*损失|乙方.*赔偿.*全部", text):
            risks.append(self._finding(clause, RiskLevel.HIGH, "违约责任明显不对等", "乙方承担全部损失", "违约责任被设计为单边、高额或无限责任，可能导致企业承担不可控赔偿暴露。", matched_rules("违约责任")))

        if clause.domain == "责任限制" and ("责任上限" not in text or "间接损失" not in text):
            risks.append(self._finding(clause, RiskLevel.HIGH, "责任限制缺失或不完整", clause.title, "合同未明确责任上限或间接损失排除，可能放大损害赔偿范围。", matched_rules("责任限制")))

        if clause.domain == "知识产权" and re.search(r"全部.*归.*甲方|永久.*免费.*使用|无条件.*转让", text):
            risks.append(self._finding(clause, RiskLevel.MEDIUM, "知识产权归属过度让渡", "全部归甲方/永久免费使用", "成果、背景知识产权与许可边界未区分，可能造成既有资产被不当让渡。", matched_rules("知识产权")))

        if clause.domain == "争议解决" and not re.search(r"适用法律|管辖|仲裁|法院", text):
            risks.append(self._finding(clause, RiskLevel.MEDIUM, "争议解决机制不明确", clause.title, "缺少适用法律、管辖法院或仲裁机构，争议发生后执行路径不清晰。", matched_rules("争议解决")))

        if clause.domain == "付款结算" and re.search(r"验收.*后.*(180|120|90).*日|账期.*(180|120|90).*日", text):
            risks.append(self._finding(clause, RiskLevel.MEDIUM, "付款周期过长", "90日以上付款账期", "长账期将提高现金流压力，且可能与企业内部授信或供应链政策冲突。", matched_rules("付款结算")))

        if clause.domain == "保密义务" and "长期" not in text and "不少于" not in text and "期限" not in text:
            risks.append(self._finding(clause, RiskLevel.LOW, "保密期限缺失", clause.title, "保密义务未设置明确期限或商业秘密持续保护机制，可执行性不足。", matched_rules("保密义务")))

        if clause.domain == "合规承诺" and not re.search(r"反贿赂|制裁|出口管制|数据|个人信息", text):
            risks.append(self._finding(clause, RiskLevel.LOW, "合规承诺覆盖不足", clause.title, "合规条款未覆盖关键监管风险，建议补充反商业贿赂、制裁、出口管制及数据合规承诺。", matched_rules("合规承诺")))

        if clause.domain == "交付验收" and "视为验收合格" in text and not ("书面" in text and "整改" in text):
            risks.append(self._finding(clause, RiskLevel.MEDIUM, "默示验收条件不利", "视为验收合格", "默示验收缺少书面确认、充分异议期和整改机制，可能导致瑕疵产品被动确认。", matched_rules("交付验收")))

        return risks

    def _finding(self, clause: Clause, level: RiskLevel, title: str, evidence: str, reasoning: str, rules: List[RetrievedRule]) -> RiskFinding:
        top_rule = rules[0] if rules else None
        suggestion = top_rule.recommendation_template if top_rule else "建议结合企业标准条款进行修订。"
        confidence = {RiskLevel.HIGH: 0.88, RiskLevel.MEDIUM: 0.78, RiskLevel.LOW: 0.66}[level]
        return RiskFinding(
            finding_id=f"R-{clause.clause_id}-{abs(hash(title)) % 10000:04d}",
            clause_id=clause.clause_id,
            domain=clause.domain,
            risk_level=level,
            title=title,
            evidence=evidence,
            reasoning=reasoning,
            legal_basis=rules,
            suggestion=suggestion,
            confidence=confidence,
        )
