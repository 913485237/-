from __future__ import annotations

from collections import Counter
from typing import List

from contract_ai.schemas import Clause, ContractProfile, ReviewResult, RiskFinding, RiskLevel


class ReportAgent:
    def run(self, profile: ContractProfile, clauses: List[Clause], findings: List[RiskFinding], original_text: str) -> ReviewResult:
        score = self._score(findings)
        redline = self._build_redline(clauses, findings)
        summary = self._build_summary(profile, findings, score)
        return ReviewResult(
            profile=profile,
            clauses=clauses,
            findings=findings,
            compliance_score=score,
            redline_text=redline,
            summary=summary,
        )

    def report_markdown(self, result: ReviewResult) -> str:
        rows = []
        for f in result.findings:
            basis = "；".join(f"{r.source}《{r.title}》" for r in f.legal_basis[:2]) or "企业标准条款库"
            rows.append(f"| {f.risk_level.value} | {f.domain} | {f.title} | {f.clause_id} | {f.confidence:.2f} | {basis} |")
        risk_rows = "\n".join(rows) if rows else "| 无明显风险 | - | - | - | - | - |"

        details = []
        for idx, f in enumerate(result.findings, start=1):
            details.append(
                f"### {idx}. {f.title}\n"
                f"- 风险等级：{f.risk_level.value}\n"
                f"- 所属条款：{f.clause_id} / {f.domain}\n"
                f"- 命中证据：{f.evidence}\n"
                f"- 推理说明：{f.reasoning}\n"
                f"- 反思校验：{f.reflection_note or '未触发额外质疑。'}\n"
                f"- 建议修改：{f.suggestion}\n"
            )

        return (
            f"# 合同风险审查报告\n\n"
            f"## 一、合同画像\n"
            f"- 合同类型：{result.profile.contract_type}\n"
            f"- 法律关系：{result.profile.legal_relation}\n"
            f"- 司法/业务辖区：{result.profile.jurisdiction}\n"
            f"- 当事方：{', '.join(result.profile.parties) or '未识别'}\n\n"
            f"## 二、综合结论\n"
            f"- 合规综合评分：{result.compliance_score}/100\n"
            f"- 审查摘要：{result.summary}\n\n"
            f"## 三、风险矩阵\n"
            f"| 风险等级 | 条款域 | 风险标题 | 条款编号 | 置信度 | 依据 |\n"
            f"|---|---|---|---|---:|---|\n"
            f"{risk_rows}\n\n"
            f"## 四、风险详情与修订建议\n\n"
            + "\n".join(details)
        )

    def _score(self, findings: List[RiskFinding]) -> int:
        penalty = 0
        for f in findings:
            penalty += {RiskLevel.HIGH: 18, RiskLevel.MEDIUM: 9, RiskLevel.LOW: 4}[f.risk_level]
        return max(0, 100 - penalty)

    def _build_summary(self, profile: ContractProfile, findings: List[RiskFinding], score: int) -> str:
        counter = Counter(f.risk_level.value for f in findings)
        if not findings:
            return f"该{profile.contract_type}未识别出明显高风险问题，建议仍由法务进行抽样复核。"
        return (
            f"该{profile.contract_type}共识别风险 {len(findings)} 项，其中高风险 {counter.get('高风险', 0)} 项、"
            f"中风险 {counter.get('中风险', 0)} 项、低风险 {counter.get('低风险', 0)} 项。"
            f"当前评分为 {score}/100，建议优先处理高风险条款后再进入签署流程。"
        )

    def _build_redline(self, clauses: List[Clause], findings: List[RiskFinding]) -> str:
        findings_by_clause: dict[str, list[RiskFinding]] = {}
        for f in findings:
            findings_by_clause.setdefault(f.clause_id, []).append(f)

        parts = ["# Redline 修订建议文本\n"]
        for clause in clauses:
            parts.append(f"## {clause.clause_id} {clause.title}\n")
            parts.append(clause.text.strip() + "\n")
            for f in findings_by_clause.get(clause.clause_id, []):
                parts.append(
                    f"> 【{f.risk_level.value}批注】{f.title}：{f.reasoning}\n\n"
                    f"> 建议替换/补充为：{f.suggestion}\n"
                )
        return "\n".join(parts)
