from __future__ import annotations

from typing import List

from contract_ai.schemas import Clause, RiskFinding, RiskLevel


class AdversarialReflectionAgent:
    """Review findings as a senior risk-control challenger.

    It asks whether a finding is under-stated or over-stated and adjusts confidence/severity.
    """

    def run(self, clauses: List[Clause], findings: List[RiskFinding]) -> List[RiskFinding]:
        clause_map = {c.clause_id: c for c in clauses}
        for finding in findings:
            clause = clause_map.get(finding.clause_id)
            if not clause:
                continue
            self._challenge(finding, clause.text)
        return sorted(findings, key=lambda f: (self._level_order(f.risk_level), -f.confidence), reverse=True)

    def _challenge(self, finding: RiskFinding, clause_text: str) -> None:
        finding.challenged = True
        notes: List[str] = []

        if finding.risk_level == RiskLevel.HIGH and any(term in clause_text for term in ["双方协商", "合理范围", "法律允许"]):
            finding.confidence = max(0.60, finding.confidence - 0.10)
            notes.append("存在一定缓释措辞，但未形成可操作的责任边界，风险仍需保留。")

        if finding.domain == "违约责任" and "对等" not in clause_text:
            finding.confidence = min(0.96, finding.confidence + 0.05)
            notes.append("反事实场景：若对方违约而我方救济不足，条款不对等将放大损失。")

        if finding.domain == "争议解决" and "跨境" in clause_text:
            finding.risk_level = RiskLevel.HIGH
            finding.confidence = min(0.95, finding.confidence + 0.08)
            notes.append("跨境执行场景下，管辖与适用法律缺失会显著提高执行不确定性。")

        if not notes:
            notes.append("未发现足以推翻原判断的缓释条件，维持原风险等级。")
        finding.reflection_note = " ".join(notes)

    @staticmethod
    def _level_order(level: RiskLevel) -> int:
        return {RiskLevel.LOW: 1, RiskLevel.MEDIUM: 2, RiskLevel.HIGH: 3}[level]
