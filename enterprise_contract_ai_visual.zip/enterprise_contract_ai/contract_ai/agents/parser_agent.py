from __future__ import annotations

import re
from typing import List

from contract_ai.schemas import Clause, ContractProfile
from contract_ai.utils.text import contains_any, extract_cross_references, split_by_numbered_clauses


DOMAIN_KEYWORDS = {
    "付款结算": ["付款", "价款", "结算", "发票", "账期"],
    "交付验收": ["交付", "验收", "交货", "质量", "质保"],
    "违约责任": ["违约", "赔偿", "罚金", "损失", "责任"],
    "责任限制": ["责任限制", "责任上限", "间接损失", "免责", "限额"],
    "知识产权": ["知识产权", "著作权", "专利", "商标", "源码", "成果"],
    "保密义务": ["保密", "商业秘密", "机密"],
    "争议解决": ["争议", "仲裁", "诉讼", "管辖", "适用法律"],
    "解除终止": ["解除", "终止", "提前终止"],
    "不可抗力": ["不可抗力"],
    "合规承诺": ["合规承诺", "合规", "反贿赂", "制裁", "出口管制", "数据合规", "个人信息"],
}


class ContractParserAgent:
    """Parse unstructured contract text into a clause tree-like structure.

    This implementation is intentionally deterministic so the project can run without an LLM key.
    In production, this agent can be replaced with OCR + LayoutLM + an LLM classifier.
    """

    def run(self, text: str) -> tuple[ContractProfile, List[Clause]]:
        profile = self._infer_profile(text)
        chunks = split_by_numbered_clauses(text)
        clauses: List[Clause] = []
        for idx, (title, body) in enumerate(chunks, start=1):
            clause_text = f"{title}\n{body}".strip()
            domain = self._classify_domain(clause_text)
            clauses.append(
                Clause(
                    clause_id=f"C{idx:03d}",
                    title=title,
                    text=body,
                    domain=domain,
                    references=extract_cross_references(clause_text),
                )
            )
        return profile, clauses

    def _classify_domain(self, text: str) -> str:
        # Heading/domain-name hits should override body keyword noise such as "合规发票".
        first_line = text.split("\n", 1)[0]
        for domain in DOMAIN_KEYWORDS:
            if domain in first_line:
                return domain
        scores = {domain: sum(1 for kw in kws if kw in text) for domain, kws in DOMAIN_KEYWORDS.items()}
        best_domain, best_score = max(scores.items(), key=lambda item: item[1])
        return best_domain if best_score > 0 else "通用条款"

    def _infer_profile(self, text: str) -> ContractProfile:
        if contains_any(text, ["融资租赁", "租赁物", "租金"]):
            contract_type = "融资租赁/复合型合同"
            legal_relation = "租赁融资法律关系"
        elif contains_any(text, ["采购", "供货", "供应商", "交货"]):
            contract_type = "采购合同"
            legal_relation = "买卖/供货法律关系"
        elif contains_any(text, ["服务", "SLA", "外包"]):
            contract_type = "服务合同"
            legal_relation = "服务提供法律关系"
        else:
            contract_type = "通用商业合同"
            legal_relation = "一般合同法律关系"

        jurisdiction = "中国大陆"
        if contains_any(text, ["香港", "新加坡", "跨境", "美元", "Inc."]):
            jurisdiction = "跨境/待确认"

        parties = re.findall(r"(?:甲方|乙方|买方|卖方)[:：]\s*([^\n]+)", text)
        return ContractProfile(
            contract_type=contract_type,
            legal_relation=legal_relation,
            jurisdiction=jurisdiction,
            parties=parties[:4],
            metadata={"source": "text_upload", "parser": "rule_based_mvp"},
        )
