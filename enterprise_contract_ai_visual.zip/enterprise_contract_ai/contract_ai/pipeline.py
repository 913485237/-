from __future__ import annotations

from contract_ai.agents.parser_agent import ContractParserAgent
from contract_ai.agents.rag_agent import HybridRAGAgent
from contract_ai.agents.risk_reasoning_agent import RiskReasoningAgent
from contract_ai.agents.reflection_agent import AdversarialReflectionAgent
from contract_ai.agents.report_agent import ReportAgent
from contract_ai.schemas import ReviewResult


class ContractReviewPipeline:
    def __init__(self):
        self.parser = ContractParserAgent()
        self.rag = HybridRAGAgent()
        self.reasoner = RiskReasoningAgent()
        self.reflector = AdversarialReflectionAgent()
        self.reporter = ReportAgent()

    def run(self, contract_text: str) -> ReviewResult:
        profile, clauses = self.parser.run(contract_text)
        retrieved = self.rag.run(clauses)
        findings = self.reasoner.run(clauses, retrieved)
        challenged_findings = self.reflector.run(clauses, findings)
        return self.reporter.run(profile, clauses, challenged_findings, contract_text)
