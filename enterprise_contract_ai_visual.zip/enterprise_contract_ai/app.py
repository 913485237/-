from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Iterable

import pandas as pd
import streamlit as st

from contract_ai.agents.report_agent import ReportAgent
from contract_ai.pipeline import ContractReviewPipeline
from contract_ai.schemas import ReviewResult, RiskFinding


BASE_DIR = Path(__file__).resolve().parent
SAMPLE_CONTRACT = BASE_DIR / "sample_contracts" / "procurement_contract.txt"

RISK_ORDER = {"高风险": 0, "中风险": 1, "低风险": 2}
LEVEL_TO_PROGRESS = {"高风险": 1.0, "中风险": 0.66, "低风险": 0.33}


st.set_page_config(
    page_title="企业级智能合同审查与合规分析系统",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {padding-top: 1.25rem; padding-bottom: 2.2rem;}
    .main-title {font-size: 2.05rem; font-weight: 760; margin-bottom: 0.15rem;}
    .sub-title {font-size: 0.98rem; color: #5f6368; margin-bottom: 1.1rem;}
    .metric-card {border: 1px solid #e5e7eb; border-radius: 18px; padding: 18px 18px; background: #ffffff; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.05);}
    .metric-label {font-size: 0.86rem; color: #6b7280; margin-bottom: 0.35rem;}
    .metric-value {font-size: 1.75rem; font-weight: 760; color: #111827;}
    .agent-card {border: 1px solid #e5e7eb; border-radius: 16px; padding: 14px 14px; min-height: 116px; background: #fafafa;}
    .agent-name {font-weight: 720; font-size: 0.98rem; margin-bottom: 0.35rem;}
    .agent-desc {font-size: 0.86rem; color: #4b5563; line-height: 1.45;}
    .risk-high {background: #fff1f2; color: #be123c; border: 1px solid #fecdd3; border-radius: 999px; padding: 3px 9px; font-size: 0.82rem; font-weight: 700;}
    .risk-medium {background: #fffbeb; color: #b45309; border: 1px solid #fde68a; border-radius: 999px; padding: 3px 9px; font-size: 0.82rem; font-weight: 700;}
    .risk-low {background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; border-radius: 999px; padding: 3px 9px; font-size: 0.82rem; font-weight: 700;}
    .small-note {font-size: 0.84rem; color: #6b7280;}
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource(show_spinner=False)
def get_pipeline() -> ContractReviewPipeline:
    return ContractReviewPipeline()


@st.cache_data(show_spinner=False)
def run_review_cached(contract_text: str) -> ReviewResult:
    pipeline = get_pipeline()
    return pipeline.run(contract_text)


def load_sample_contract() -> str:
    return SAMPLE_CONTRACT.read_text(encoding="utf-8")


def decode_uploaded_file(uploaded_file) -> str:
    raw = uploaded_file.getvalue()
    for encoding in ("utf-8", "gb18030", "gbk"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def metric_card(label: str, value: str, help_text: str = "") -> None:
    st.markdown(
        f"""
        <div class="metric-card">
          <div class="metric-label">{label}</div>
          <div class="metric-value">{value}</div>
          <div class="small-note">{help_text}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def risk_badge(level: str) -> str:
    css = {"高风险": "risk-high", "中风险": "risk-medium", "低风险": "risk-low"}.get(level, "risk-low")
    return f'<span class="{css}">{level}</span>'


def finding_rows(findings: Iterable[RiskFinding]) -> list[dict[str, object]]:
    rows = []
    for f in findings:
        basis = "；".join(f"{r.source}《{r.title}》" for r in f.legal_basis[:2]) or "企业标准条款库"
        rows.append(
            {
                "风险等级": f.risk_level.value,
                "条款编号": f.clause_id,
                "条款域": f.domain,
                "风险标题": f.title,
                "命中证据": f.evidence,
                "置信度": round(f.confidence, 2),
                "依据": basis,
                "建议修改": f.suggestion,
            }
        )
    return rows


def build_clause_tree_df(result: ReviewResult) -> pd.DataFrame:
    risk_by_clause: dict[str, list[RiskFinding]] = {}
    for f in result.findings:
        risk_by_clause.setdefault(f.clause_id, []).append(f)

    rows = []
    for clause in result.clauses:
        clause_findings = risk_by_clause.get(clause.clause_id, [])
        highest = "无明显风险"
        if clause_findings:
            highest = sorted((f.risk_level.value for f in clause_findings), key=lambda x: RISK_ORDER[x])[0]
        rows.append(
            {
                "条款编号": clause.clause_id,
                "标题": clause.title,
                "条款域": clause.domain,
                "交叉引用": "、".join(clause.references) if clause.references else "-",
                "风险数量": len(clause_findings),
                "最高风险": highest,
                "条款摘要": clause.text[:110] + ("..." if len(clause.text) > 110 else ""),
            }
        )
    return pd.DataFrame(rows)


def build_legal_basis_df(result: ReviewResult) -> pd.DataFrame:
    seen: set[str] = set()
    rows = []
    for f in result.findings:
        for rule in f.legal_basis:
            if rule.rule_id in seen:
                continue
            seen.add(rule.rule_id)
            rows.append(
                {
                    "规则ID": rule.rule_id,
                    "来源": rule.source,
                    "规则名称": rule.title,
                    "条款域": rule.domain,
                    "严重度": rule.severity,
                    "规则摘要": rule.rule_text,
                    "标准建议": rule.recommendation_template,
                }
            )
    return pd.DataFrame(rows)


def render_agent_flow() -> None:
    agents = [
        ("1. 解析 Agent", "版面/OCR 接入位、合同类型识别、当事方抽取、条款树拆解。"),
        ("2. Hybrid RAG Agent", "向量检索 + 规则库/知识图谱检索，匹配法律法规和企业红线。"),
        ("3. 风险推理 Agent", "基于证据、依据和业务影响生成结构化风险结论。"),
        ("4. 反思 Agent", "对风险结论做反事实质疑，修正等级和置信度。"),
        ("5. 输出 Agent", "生成评分、风险矩阵、审查报告和 Redline 修订建议。"),
    ]
    cols = st.columns(len(agents))
    for col, (name, desc) in zip(cols, agents):
        with col:
            st.markdown(
                f'<div class="agent-card"><div class="agent-name">{name}</div><div class="agent-desc">{desc}</div></div>',
                unsafe_allow_html=True,
            )


def render_overview(result: ReviewResult) -> None:
    counter = Counter(f.risk_level.value for f in result.findings)
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        metric_card("合规评分", f"{result.compliance_score}/100", "低于 70 建议法务复核后再签署")
    with col2:
        metric_card("风险总数", str(len(result.findings)), "按高/中/低等级汇总")
    with col3:
        metric_card("高风险", str(counter.get("高风险", 0)), "优先处理，建议阻断签署")
    with col4:
        metric_card("合同类型", result.profile.contract_type, result.profile.legal_relation)

    st.markdown("#### 多 Agent 审查流程")
    render_agent_flow()

    st.markdown("#### 综合结论")
    st.info(result.summary)

    chart_col, profile_col = st.columns([1.15, 0.85])
    with chart_col:
        st.markdown("#### 风险等级分布")
        severity_df = pd.DataFrame(
            [
                {"风险等级": "高风险", "数量": counter.get("高风险", 0)},
                {"风险等级": "中风险", "数量": counter.get("中风险", 0)},
                {"风险等级": "低风险", "数量": counter.get("低风险", 0)},
            ]
        ).set_index("风险等级")
        st.bar_chart(severity_df, height=280)
    with profile_col:
        st.markdown("#### 合同画像")
        st.write(f"**法律关系：** {result.profile.legal_relation}")
        st.write(f"**司法/业务辖区：** {result.profile.jurisdiction}")
        st.write(f"**当事方：** {', '.join(result.profile.parties) or '未识别'}")
        st.write(f"**条款数量：** {len(result.clauses)}")
        st.write(f"**解析器：** {result.profile.metadata.get('parser', '-')}")


def render_risk_matrix(result: ReviewResult) -> None:
    rows = finding_rows(result.findings)
    if not rows:
        st.success("未识别出明显风险。")
        return

    risk_df = pd.DataFrame(rows)
    risk_df["排序"] = risk_df["风险等级"].map(RISK_ORDER)
    risk_df = risk_df.sort_values(["排序", "置信度"], ascending=[True, False]).drop(columns=["排序"])

    levels = ["全部"] + [x for x in ["高风险", "中风险", "低风险"] if x in set(risk_df["风险等级"])]
    domains = ["全部"] + sorted(risk_df["条款域"].unique().tolist())
    filter_col1, filter_col2 = st.columns(2)
    selected_level = filter_col1.selectbox("按风险等级筛选", levels)
    selected_domain = filter_col2.selectbox("按条款域筛选", domains)

    view_df = risk_df.copy()
    if selected_level != "全部":
        view_df = view_df[view_df["风险等级"] == selected_level]
    if selected_domain != "全部":
        view_df = view_df[view_df["条款域"] == selected_domain]

    st.dataframe(view_df, use_container_width=True, hide_index=True, height=360)

    st.markdown("#### 风险详情")
    for f in sorted(result.findings, key=lambda x: (RISK_ORDER[x.risk_level.value], -x.confidence)):
        if selected_level != "全部" and f.risk_level.value != selected_level:
            continue
        if selected_domain != "全部" and f.domain != selected_domain:
            continue
        title = f"{f.risk_level.value}｜{f.clause_id}｜{f.title}｜置信度 {f.confidence:.2f}"
        with st.expander(title, expanded=f.risk_level.value == "高风险"):
            st.markdown(risk_badge(f.risk_level.value), unsafe_allow_html=True)
            st.write(f"**所属条款域：** {f.domain}")
            st.write(f"**命中证据：** {f.evidence}")
            st.write(f"**推理说明：** {f.reasoning}")
            st.write(f"**反思校验：** {f.reflection_note or '未触发额外质疑。'}")
            st.write(f"**建议修改：** {f.suggestion}")
            if f.legal_basis:
                st.write("**依据：**")
                for rule in f.legal_basis[:3]:
                    st.write(f"- {rule.source}《{rule.title}》：{rule.rule_text}")


def render_clause_tree(result: ReviewResult) -> None:
    st.markdown("#### 条款树与风险映射")
    st.dataframe(build_clause_tree_df(result), use_container_width=True, hide_index=True, height=410)

    st.markdown("#### 单条款查看")
    clause_options = [f"{c.clause_id}｜{c.title}｜{c.domain}" for c in result.clauses]
    selected = st.selectbox("选择条款", clause_options)
    selected_clause_id = selected.split("｜", 1)[0]
    clause = next(c for c in result.clauses if c.clause_id == selected_clause_id)
    st.text_area("条款正文", clause.text, height=180, disabled=True)

    clause_findings = [f for f in result.findings if f.clause_id == selected_clause_id]
    if clause_findings:
        for f in clause_findings:
            st.warning(f"{f.risk_level.value}：{f.title}\n\n建议：{f.suggestion}")
    else:
        st.success("该条款未命中明显风险。")


def render_redline(result: ReviewResult) -> None:
    st.markdown("#### Redline 修订建议")
    st.markdown(result.redline_text)


def render_knowledge(result: ReviewResult) -> None:
    st.markdown("#### 本次审查命中的法规/企业规则")
    basis_df = build_legal_basis_df(result)
    if basis_df.empty:
        st.info("未命中外部规则，当前结果主要来自企业标准条款库。")
    else:
        st.dataframe(basis_df, use_container_width=True, hide_index=True, height=420)


def render_exports(result: ReviewResult) -> None:
    reporter = ReportAgent()
    json_text = json.dumps(result.to_dict(), ensure_ascii=False, indent=2)
    markdown_report = reporter.report_markdown(result)

    st.markdown("#### 导出审查产物")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.download_button("下载 JSON 结构化结果", json_text, "contract_review_result.json", mime="application/json")
    with col2:
        st.download_button("下载 Markdown 审查报告", markdown_report, "contract_review_report.md", mime="text/markdown")
    with col3:
        st.download_button("下载 Redline 修订建议", result.redline_text, "redline_contract.md", mime="text/markdown")

    st.markdown("#### API 集成示例")
    st.code(
        """from contract_ai.pipeline import ContractReviewPipeline

pipeline = ContractReviewPipeline()
result = pipeline.run(contract_text)
review_payload = result.to_dict()  # 可写入法务系统、合同系统或审批流
""",
        language="python",
    )


st.markdown('<div class="main-title">企业级智能合同审查与合规分析系统</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="sub-title">面向公司内部法务、采购、风控和业务审批的可视化操作台：上传合同 → 多 Agent 审查 → 风险矩阵 → Redline 修订 → 报告导出。</div>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("操作台")
    st.caption("当前版本为离线 MVP，便于演示和二次开发。生产环境可接入 OCR、Word/PDF 解析、私有 LLM、向量库和法规知识图谱。")
    uploaded = st.file_uploader("上传合同文本", type=["txt", "md"], help="MVP 支持 TXT/Markdown。PDF/Word 可通过生产解析器接入。")
    use_sample = st.toggle("使用示例采购合同", value=uploaded is None)
    st.divider()
    review_mode = st.selectbox("审查强度", ["标准审查", "严格审查", "快速初筛"], index=0)
    business_position = st.selectbox("企业立场", ["采购方/甲方", "供应商/乙方", "中性审查"], index=0)
    st.caption(f"审查强度：{review_mode}；企业立场：{business_position}。当前 MVP 使用固定规则库，生产版可将该配置传入提示词和规则引擎。")

if uploaded is not None and not use_sample:
    default_text = decode_uploaded_file(uploaded)
else:
    default_text = load_sample_contract()

input_col, action_col = st.columns([0.68, 0.32])
with input_col:
    contract_text = st.text_area("合同文本", value=default_text, height=290, placeholder="在此粘贴合同正文，或从左侧上传 TXT/Markdown 文件。")
with action_col:
    st.markdown("#### 审查前检查")
    st.write(f"字符数：**{len(contract_text)}**")
    st.write(f"预计条款：**{contract_text.count('第')}**")
    st.write("支持输出：风险矩阵、条款树、红线批注、报告、JSON。")
    run_button = st.button("开始智能审查", type="primary", use_container_width=True)
    clear_button = st.button("清空审查结果", use_container_width=True)

if clear_button:
    st.session_state.pop("review_result", None)

if run_button:
    if not contract_text.strip():
        st.error("合同文本为空。请粘贴合同或上传文件后再审查。")
    else:
        with st.spinner("多 Agent 正在执行解析、检索、推理、反思和报告生成。"):
            st.session_state["review_result"] = run_review_cached(contract_text)

result = st.session_state.get("review_result")

if result is None:
    st.markdown("#### 可视化能力预览")
    render_agent_flow()
    st.info("点击“开始智能审查”后，将生成风险仪表盘、条款树、风险矩阵、Redline 修订建议和可下载报告。")
else:
    tabs = st.tabs(["总览仪表盘", "风险矩阵", "条款树", "Redline 修订", "法规/规则依据", "导出与集成"])
    with tabs[0]:
        render_overview(result)
    with tabs[1]:
        render_risk_matrix(result)
    with tabs[2]:
        render_clause_tree(result)
    with tabs[3]:
        render_redline(result)
    with tabs[4]:
        render_knowledge(result)
    with tabs[5]:
        render_exports(result)
