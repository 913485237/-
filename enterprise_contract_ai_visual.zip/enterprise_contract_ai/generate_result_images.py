from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.font_manager import FontProperties


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "outputs"
FONT_CANDIDATES = [
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "C:/Windows/Fonts/msyh.ttc",
]
FONT_PATH = next((p for p in FONT_CANDIDATES if Path(p).exists()), None)
FONT = FontProperties(fname=FONT_PATH) if FONT_PATH else None


def fp(size: int = 10, weight: str | None = None):
    if FONT_PATH:
        return FontProperties(fname=FONT_PATH, size=size, weight=weight)
    return None


def generate_architecture() -> None:
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.axis("off")
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 8)

    boxes = [
        (0.6, 5.8, 2.2, 1.0, "合同输入\nPDF/Word/扫描件"),
        (3.2, 5.8, 2.2, 1.0, "解析 Agent\nOCR/Layout/条款树"),
        (5.8, 5.8, 2.2, 1.0, "Hybrid RAG\n法规+制度+知识图谱"),
        (8.4, 5.8, 2.2, 1.0, "推理 Agent\n条款风险判定"),
        (11.0, 5.8, 2.2, 1.0, "反思 Agent\n对抗质疑/复核"),
        (5.8, 3.8, 2.2, 1.0, "企业知识库\n红线/案例/条款库"),
        (8.4, 2.0, 2.2, 1.0, "输出 Agent\n报告+评分+Redline"),
        (11.0, 2.0, 2.2, 1.0, "人工反馈闭环\nFew-Shot 沉淀"),
    ]

    for x, y, w, h, label in boxes:
        box = patches.FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.08", linewidth=1.5, facecolor="white", edgecolor="black"
        )
        ax.add_patch(box)
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontproperties=fp(11))

    arrows = [
        ((2.8, 6.3), (3.2, 6.3)),
        ((5.4, 6.3), (5.8, 6.3)),
        ((8.0, 6.3), (8.4, 6.3)),
        ((10.6, 6.3), (11.0, 6.3)),
        ((6.9, 5.8), (6.9, 4.8)),
        ((6.9, 3.8), (8.8, 3.0)),
        ((9.5, 5.8), (9.5, 3.0)),
        ((12.1, 5.8), (12.1, 3.0)),
        ((10.6, 2.5), (11.0, 2.5)),
        ((12.1, 2.0), (12.1, 1.2)),
        ((12.1, 1.2), (6.9, 1.2)),
        ((6.9, 1.2), (6.9, 3.8)),
    ]
    for start, end in arrows:
        ax.annotate("", xy=end, xytext=start, arrowprops=dict(arrowstyle="->", lw=1.4))

    ax.text(7, 7.45, "企业级智能合同审查与合规分析系统：多 Agent 协作架构", ha="center", fontproperties=fp(17, "bold"))
    ax.text(7, 0.55, "核心闭环：解析 → 检索增强 → 风险推理 → 对抗反思 → 报告/Redline → 人工反馈沉淀", ha="center", fontproperties=fp(11))
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "architecture.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def generate_risk_matrix() -> None:
    data = json.loads((OUTPUT_DIR / "pipeline_result.json").read_text(encoding="utf-8"))
    findings = data["findings"]
    domains = sorted({f["domain"] for f in findings})
    levels = ["高风险", "中风险", "低风险"]
    matrix = [[0 for _ in levels] for _ in domains]
    index = {d: i for i, d in enumerate(domains)}
    level_index = {l: i for i, l in enumerate(levels)}
    for f in findings:
        matrix[index[f["domain"]]][level_index[f["risk_level"]]] += 1

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.imshow(matrix)
    ax.set_xticks(range(len(levels)), labels=levels, fontproperties=fp(11))
    ax.set_yticks(range(len(domains)), labels=domains, fontproperties=fp(11))
    ax.set_title("示例合同风险矩阵", fontproperties=fp(15, "bold"))
    ax.set_xlabel("风险等级", fontproperties=fp(11))
    ax.set_ylabel("条款域", fontproperties=fp(11))

    for i, domain in enumerate(domains):
        for j, level in enumerate(levels):
            ax.text(j, i, str(matrix[i][j]), ha="center", va="center", fontproperties=fp(13, "bold"))

    score = data["compliance_score"]
    counts = Counter(f["risk_level"] for f in findings)
    note = f"合规评分：{score}/100；高风险 {counts.get('高风险', 0)} 项，中风险 {counts.get('中风险', 0)} 项，低风险 {counts.get('低风险', 0)} 项"
    fig.text(0.5, 0.02, note, ha="center", fontproperties=fp(11))
    fig.tight_layout(rect=[0, 0.05, 1, 1])
    fig.savefig(OUTPUT_DIR / "risk_matrix.png", dpi=180, bbox_inches="tight")
    plt.close(fig)




def generate_visual_console_preview() -> None:
    """Create a static preview image for non-technical stakeholders.

    The real UI is Streamlit (`streamlit run app.py`). This PNG is a lightweight
    visual artifact that can be inserted into slides or project documents.
    """
    data = json.loads((OUTPUT_DIR / "pipeline_result.json").read_text(encoding="utf-8"))
    findings = data["findings"]
    counts = Counter(f["risk_level"] for f in findings)

    fig, ax = plt.subplots(figsize=(15, 9))
    ax.axis("off")
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 9)

    # outer browser canvas
    ax.add_patch(patches.FancyBboxPatch((0.25, 0.25), 14.5, 8.5, boxstyle="round,pad=0.02,rounding_size=0.12", linewidth=1.2, facecolor="#f8fafc", edgecolor="#d1d5db"))
    ax.add_patch(patches.FancyBboxPatch((0.25, 8.25), 14.5, 0.5, boxstyle="round,pad=0.02,rounding_size=0.12", linewidth=1.2, facecolor="#ffffff", edgecolor="#d1d5db"))
    for x in [0.55, 0.82, 1.09]:
        ax.add_patch(patches.Circle((x, 8.50), 0.065, facecolor="#cbd5e1", edgecolor="none"))

    # sidebar
    ax.add_patch(patches.FancyBboxPatch((0.45, 0.5), 3.0, 7.55, boxstyle="round,pad=0.02,rounding_size=0.08", linewidth=1.0, facecolor="#ffffff", edgecolor="#e5e7eb"))
    ax.text(1.95, 7.65, "操作台", ha="center", va="center", fontproperties=fp(14, "bold"))
    sidebar_items = ["上传合同文本", "审查强度：标准审查", "企业立场：采购方/甲方", "开始智能审查"]
    y = 7.05
    for idx, label in enumerate(sidebar_items):
        face = "#e0f2fe" if idx == 3 else "#f3f4f6"
        ax.add_patch(patches.FancyBboxPatch((0.75, y - 0.22), 2.4, 0.44, boxstyle="round,pad=0.02,rounding_size=0.07", linewidth=0.8, facecolor=face, edgecolor="#e5e7eb"))
        ax.text(1.95, y, label, ha="center", va="center", fontproperties=fp(9))
        y -= 0.72

    # main title
    ax.text(4.0, 7.72, "企业级智能合同审查与合规分析系统", ha="left", va="center", fontproperties=fp(16, "bold"))
    ax.text(4.0, 7.32, "上传合同 → 多 Agent 审查 → 风险矩阵 → Redline 修订 → 报告导出", ha="left", va="center", fontproperties=fp(10))

    # KPI cards
    kpis = [
        ("合规评分", f"{data['compliance_score']}/100"),
        ("风险总数", str(len(findings))),
        ("高风险", str(counts.get("高风险", 0))),
        ("合同类型", data["profile"]["contract_type"]),
    ]
    x = 4.0
    for label, value in kpis:
        ax.add_patch(patches.FancyBboxPatch((x, 6.25), 2.45, 0.72, boxstyle="round,pad=0.025,rounding_size=0.10", linewidth=1.0, facecolor="#ffffff", edgecolor="#e5e7eb"))
        ax.text(x + 0.18, 6.76, label, ha="left", va="center", fontproperties=fp(8))
        ax.text(x + 0.18, 6.43, value, ha="left", va="center", fontproperties=fp(14, "bold"))
        x += 2.65

    # agent flow
    agents = ["解析", "RAG", "推理", "反思", "输出"]
    x = 4.0
    for idx, label in enumerate(agents):
        ax.add_patch(patches.FancyBboxPatch((x, 5.35), 1.55, 0.48, boxstyle="round,pad=0.02,rounding_size=0.08", linewidth=1.0, facecolor="#ffffff", edgecolor="#d1d5db"))
        ax.text(x + 0.775, 5.59, f"{idx+1}. {label} Agent", ha="center", va="center", fontproperties=fp(9, "bold"))
        if idx < len(agents) - 1:
            ax.annotate("", xy=(x + 1.83, 5.59), xytext=(x + 1.55, 5.59), arrowprops=dict(arrowstyle="->", lw=1.0, color="#64748b"))
        x += 1.9

    # risk matrix table block
    ax.add_patch(patches.FancyBboxPatch((4.0, 2.95), 5.3, 2.05, boxstyle="round,pad=0.02,rounding_size=0.08", linewidth=1.0, facecolor="#ffffff", edgecolor="#e5e7eb"))
    ax.text(4.2, 4.72, "风险矩阵", ha="left", va="center", fontproperties=fp(12, "bold"))
    rows = findings[:5]
    table_y = 4.35
    for f in rows:
        ax.text(4.22, table_y, f["risk_level"], ha="left", va="center", fontproperties=fp(8))
        ax.text(5.05, table_y, f["clause_id"], ha="left", va="center", fontproperties=fp(8))
        ax.text(5.75, table_y, f["title"][:20], ha="left", va="center", fontproperties=fp(8))
        table_y -= 0.32

    # chart block
    ax.add_patch(patches.FancyBboxPatch((9.55, 2.95), 4.65, 2.05, boxstyle="round,pad=0.02,rounding_size=0.08", linewidth=1.0, facecolor="#ffffff", edgecolor="#e5e7eb"))
    ax.text(9.75, 4.72, "风险等级分布", ha="left", va="center", fontproperties=fp(12, "bold"))
    bar_labels = ["高", "中", "低"]
    bar_vals = [counts.get("高风险", 0), counts.get("中风险", 0), counts.get("低风险", 0)]
    for i, (lbl, val) in enumerate(zip(bar_labels, bar_vals)):
        bx = 10.0 + i * 1.2
        ax.add_patch(patches.Rectangle((bx, 3.25), 0.45, 0.22 * max(val, 0.3), facecolor="#cbd5e1", edgecolor="#64748b", linewidth=0.8))
        ax.text(bx + 0.22, 3.08, lbl, ha="center", va="center", fontproperties=fp(9))
        ax.text(bx + 0.22, 3.38 + 0.22 * val, str(val), ha="center", va="center", fontproperties=fp(9, "bold"))

    # redline block
    ax.add_patch(patches.FancyBboxPatch((4.0, 0.75), 10.2, 1.8, boxstyle="round,pad=0.02,rounding_size=0.08", linewidth=1.0, facecolor="#ffffff", edgecolor="#e5e7eb"))
    ax.text(4.2, 2.28, "Redline 修订建议", ha="left", va="center", fontproperties=fp(12, "bold"))
    ax.text(4.25, 1.88, "【高风险批注】责任限制缺失或不完整：建议补充责任上限、间接损失排除及例外情形。", ha="left", va="center", fontproperties=fp(9))
    ax.text(4.25, 1.47, "建议替换/补充为：除故意、重大过失、保密及知识产权侵权外，双方累计赔偿责任不超过合同总价。", ha="left", va="center", fontproperties=fp(9))
    ax.text(4.25, 1.06, "支持一键导出 JSON、Markdown 审查报告与红线修订稿。", ha="left", va="center", fontproperties=fp(9))

    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "visual_console_preview.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    OUTPUT_DIR.mkdir(exist_ok=True)
    generate_architecture()
    generate_risk_matrix()
    generate_visual_console_preview()
    print(f"Images saved to: {OUTPUT_DIR}")
